
package Controller;

import java.util.*;
import Model.Librarian;
import Model.InputCustomer;
import static Model.Librarian.list;
import View.Menu;
import java.text.*;



public class LibraryManagement extends Menu<String> {
    static String[] menu = { "Customer", "Librarian"};
    private Librarian bookList = new Librarian();
    private Validate check = new Validate();
    
    public LibraryManagement() {
        super("Library Management System!!!", menu);
    }

    @Override
    public void execute(int n) {
        switch (n) {
            case 1:
                customerFind();
                break;
            case 2:
                librarianFind();
                break;
}       
}
    public void customerFind() {
        String[] mSearch = {"Find by ID Book", "Find by Name Author", "Find by Kind Of Book", "Find by Language"};
        Menu m = new Menu("Customer Searching", mSearch) {
            @Override
            public void execute(int n) {
                ArrayList<InputCustomer> rs = null;
                switch (n) {

                    case 1:
                        String val = check.checkIdBook("Enter Book ID: ");
                        rs = bookList.search(c -> c.getIdBook().equalsIgnoreCase(val));
                        break;
                    case 2:
                        val = check.checkNameAuthor("Enter Author's name: ");
                        rs = bookList.search(c -> c.getNameAuthor().contains(val));
                        break;
                    case 3:
                        val = check.checkKindOfBook("We have literature and document book. Please choice and enter one:");
                        rs = bookList.search(c -> c.getKindOfBook().contains(val));
                        break;
                    case 4:
                        val = check.checkLanguage("We have Enlish and Vietnamese . Please choice and enter one:");
                        rs = bookList.search(c -> c.getLanguage().contains(val));
                        break;       
                }
                
//                if (rs == null) {
//                    System.out.println("Not found data");
//                } else {
                    for (InputCustomer r : rs) {
                        System.out.println(r);
                    }
//                }
            }
    };
        m.execute(m.getSelected());
        m.run();
}
    public void librarianFind(){
        String[] mSearch = {"List all of book"," Read text file to load data","Write data in list book","Find by ID Book", "Find by Name Author", "Find by Kind Of Book", "Find by Language", "Delete book", "Add new book", "Update infor book"};
        Menu m = new Menu("Customer Searching", mSearch) {
            @Override
            public void execute(int n) {
                ArrayList<InputCustomer> rs = null;
                switch (n) {
                    case 1:
                        displayBook();
                        break;
                    case 2:
                        bookList.readFile("src/file/list.txt");
                        bookList.displayList();
                        break;
                    case 3:
                        bookList.writeFile(list, "src/file/list.txt");
                    case 4:
                        String val = check.checkIdBook("Enter Book ID: ");
                        rs = bookList.search(c -> c.getIdBook().equalsIgnoreCase(val));
                        break;
                    case 5:
                        val = check.checkNameAuthor("Enter Author's name: ");
                        rs = bookList.search(c -> c.getNameAuthor().contains(val));
                        break;
                    case 6:
                        val = check.checkKindOfBook("We have literature and document book. Please choice and enter one:");
                        rs = bookList.search(c -> c.getNameAuthor().equalsIgnoreCase(val));
                        break;
                    case 7:
                        val = check.checkLanguage("We have literature and document book. Please choice and enter one:");
                        rs = bookList.search(c -> c.getNameAuthor().equalsIgnoreCase(val));
                        break; 
                    case 8: 
                        deleteBook();
                    case 9:
                        bookList.addBook(enterBook());
                        break;
                    case 10:
                        String idFind = check.checkIdBook("Enter custome's ID you want to update info");
                        updateInfo(idFind);
                        
                }
            }
        };
        m.execute(m.getSelected());
        m.run();
    }
    
    
    
        public void displayBook() {
        System.out.println("---Book List---");
        bookList.displayList();
    }
    
    
    public void deleteBook() {
        String IdBook = check.checkIdBook("Enter ID:");
        bookList.delete(IdBook);

    }
    
    public InputCustomer enterBook() {
        String idBook = check.checkIdBook("Enter CustomerID: ");
        String nameAuthor = check.checkNameAuthor("Enter customer name: ");
        String KindOfBook = check.checkKindOfBook("Enter customer phone: ");
        String language = check.checkLanguage("Enter date of birth: ");
        return new InputCustomer(idBook, nameAuthor, KindOfBook, language);

    }
        
        
        
        
    public void updateInfo(String idFind) {
        String[] mSearch = {"Update Kind Of Book", "Update NameAuthor", "Update Language"};
        Menu m = new Menu("Customer update", mSearch) {
            @Override
            public void execute(int n) {
                
                if(n==1){
                     for (InputCustomer a : list) {
                            if (a.getIdBook().equals(idFind)) {
                                String newKind = check.checkKindOfBook("Input new kind of book " + idFind);
                                a.setKindOfBook(newKind);   
                                System.out.println("Update successfully");
                                break;
                            }else{
                                System.err.println("ID not found!!!");
                                break;
                            }
                        }
                }
                if(n==2){
                    for (InputCustomer a : list) {
                            if (a.getIdBook().equals(idFind)) {
                                String newName = check.checkNameAuthor("Input new name Author " + idFind);
                                a.setNameAuthor(newName);
                                
                            }else{
                                System.err.println("ID not found!!!");
                                break;
                            }
                        }
                }
                if (n==3){
                    for (InputCustomer a : list) {
                            if (a.getLanguage().equals(idFind)) {
                                String newLanguage = check.checkLanguage("Input new language " + idFind);
                                a.setNameAuthor(newLanguage);
                                
                            }else{
                                System.err.println("ID not found!!!");
                                break;
                            }
                        }
                    
                }

            }
        };
        m.execute(m.getSelected());
        m.run();
    }
        
}
