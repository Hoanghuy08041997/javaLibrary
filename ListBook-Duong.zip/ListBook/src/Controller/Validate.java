
package Controller;

import Model.Librarian;
import java.util.Scanner;


public class Validate extends Librarian {
    public Scanner sc = new Scanner(System.in);
    public Librarian com = new Librarian();
    
    
//-------------
    public String inputString(String msg) {
        String str;
        while (true) {
            System.out.println(msg);
            str = sc.nextLine();
            if (str == null || str.length() == 0) {
                System.err.println("It can't empty, try again!!!");
                continue;
            }
            return str.trim();
        }
    }    
//---------------------------   
    public String checkIdBook(String msg) {
        String regex = "BO100\\d[2}]";
        while (true) {
            String id = inputString(msg);
            //boolean check = true;
            if (id.matches(regex)) {
                return id;
            } else {
                System.err.println("It must be like this form(BO100**)");
            }

        }
    }
    
    
//-------------------------
    public String checkNameAuthor(String msg) {
        String regex = "[A-Z]+";
        while (true) {
            String name = inputString(msg);
            if (name.matches(regex)) {
                return name;
            } else {
                System.err.println("It must not contain any number or speacial character and must be capital letters");
            }
        }
    }
    
    
//-------------------
    public String checkKindOfBook(String msg) {
        String regex = "[A-Z]+";
        while (true) {
            String name = inputString(msg);
            if (name.matches(regex)) {
                return name;
            } else {
                System.err.println("It must be literature or document book.");
            }
        }
    }

    
//-------------------
    public String checkLanguage(String msg) {
        String regex = "[A-Z]+";
        while (true) {
            String name = inputString(msg);
            if (name.matches(regex)) {
                return name;
            } else {
                System.err.println("It must be English or Vietnamese");
            }
        }
    }
//-------------------

    public int checkNum(String msg) {
        String regex = "^[0-9]";
        int number = 0;
        while (true) {
//            try {
                String num = inputString(msg);
                if (num.matches(regex)) {
                    number = Integer.parseInt(num);
                    return number;
                } else {
                    System.err.println("It must be a number");

                }
//            } 
//            catch (NumberFormatException e) {
//                System.err.println("It must be a number");
//            }

        }
 
}
}
