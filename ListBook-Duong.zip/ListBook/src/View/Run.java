
package View;

import Controller.LibraryManagement;


public class Run {
    public static LibraryManagement com = new LibraryManagement();
    
public static void main(String[] args) throws Exception {
         com.run();
 
}
}
