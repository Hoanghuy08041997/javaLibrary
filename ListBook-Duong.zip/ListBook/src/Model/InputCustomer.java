/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.*;


public class InputCustomer {


    private String idBook;
    private String nameAuthor;
    private String language;
    private String KindOfBook;
    private int value;
    
    public InputCustomer(String idBook, String nameAuthor, String language, String KindOfBook)  {
        this.idBook = idBook;
        this.nameAuthor = nameAuthor;
        this.language = language;
        this.KindOfBook = KindOfBook;
    }

    public String getIdBook() {
        return idBook;
    }

    public void setIdBook(String idBook) {
        this.idBook = idBook;
    }

    public String getNameAuthor() {
        return nameAuthor;
    }

    public void setNameAuthor(String nameAuthor) {
        this.nameAuthor = nameAuthor;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getKindOfBook() {
        return KindOfBook;
    }

    public void setKindOfBook(String KindOfBook) {
        this.KindOfBook = KindOfBook;
    }

    @Override
    public String toString() {
        return "InputCustomer{" + "id=" + idBook + ", name=" + nameAuthor + ", KindBook=" + KindOfBook + '}';
    }
    
}
