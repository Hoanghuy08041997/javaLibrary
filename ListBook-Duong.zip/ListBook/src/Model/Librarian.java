
package Model;

import Controller.LibraryManagement;
import Controller.Validate;
import java.io.*;
import java.util.*;
import java.util.function.Predicate;




public class Librarian {
    private Scanner sc = new Scanner(System.in);
    public static ArrayList<InputCustomer> list = new ArrayList<>();
    public static LibraryManagement com = new LibraryManagement();
    public static Validate val = new Validate();
    
    //xuat danh sach ------------------------------------------------------------    
    public void displayList() {
        if (list.isEmpty()) {
            System.out.println("Sorry, the list is empty");
        }
        for (InputCustomer book : list) {
            System.out.println(book.toString());
        }
    }
//------------------------------------------------------------

    public ArrayList<InputCustomer> search(Predicate<InputCustomer> c) {
        ArrayList<InputCustomer> rs = new ArrayList<>();
        for (InputCustomer customer : list) {
            if (c.test(customer)) {
                rs.add(customer);
            }
        }
        return rs;
    }
//------------------------------------------------------------

    public void addBook(InputCustomer e) {
        list.add(e);
    }
//------------------------------------------------------------
//------------------------------------------------------------

    public void writeFile(ArrayList<InputCustomer> list, String path) {
        try {
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path)));
            for (InputCustomer book : list) {
                String line = book.getIdBook() + "," +book.getNameAuthor() + ", " + book.getKindOfBook() + "," + book.getLanguage();
                bw.write(line);
                bw.newLine();
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
//------------------------------------------------------------

    public static void readFile(String path) {

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
            String line = br.readLine();

            while (line != null) {
                String[] sub = line.split(",");
                if (sub.length == 5) {
                    String bookIdBook = sub[0];
                    boolean isExisting = false;

                    for (InputCustomer book  : list) {
                        if (book.getIdBook().equals(bookIdBook)) {
                            isExisting = true;
                            break;
                        }
                    }

                    if (!isExisting) {
                        InputCustomer c = new InputCustomer(sub[0], sub[1], sub[2], sub[3]);
                        list.add(c);
                    }
                }
                line = br.readLine();
            }
            System.out.println("Read successfully");
            br.close();
        } catch (Exception e) {
            System.out.println("Failed to read");
            e.printStackTrace();
        }
    }
//------------------------------------------------------------

    public void delete(String IdBook) {
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getIdBook().equalsIgnoreCase(IdBook)) {
                System.out.println(list.get(i).toString());
                count++;
            }
        }
        if (count != 0) {
            String choose = val.inputString("Do you want to delete? (Y/N)");
            if (choose.equalsIgnoreCase("Y")) {
                System.out.println("Deleted from the list");
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getIdBook().equalsIgnoreCase(IdBook)) {
                        list.remove(i);
                    }
                }

            } else if (choose.equalsIgnoreCase("N")) {
                System.out.println("Cancelled");
            }
        } else {
            System.out.println(IdBook+ " cannot be found");
        }

}
}
